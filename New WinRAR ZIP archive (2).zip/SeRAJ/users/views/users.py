from django.shortcuts import redirect, render
from django.views.generic import TemplateView


def home(request):
    if request.user.is_authenticated:
        if request.user.is_Administrative:
            return redirect('')
        elif request.user.is_Professor:
            return redirect('')
    return render(request, 'home.html')