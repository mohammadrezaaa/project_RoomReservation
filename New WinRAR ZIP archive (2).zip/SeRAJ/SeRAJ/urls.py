from django.urls import include, path
from django.contrib import admin

from users.views import professors, administratives

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('users.urls')),
    path('', include('rooms.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/signup/professor/', professors.ProfessorsSignUpView.as_view(), name='professor_signup'),
    path('accounts/signup/administrative/', administratives.AdministrativesSignUpView.as_view(), name='administrative_signup'),
]
